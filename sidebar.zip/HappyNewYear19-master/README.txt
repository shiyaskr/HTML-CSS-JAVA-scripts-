A Pen created at CodePen.io. You can find this one at https://codepen.io/Sector22/pen/KwNpWr.

 Created this text animation for a [personal new years project](http://www.sector22.com/newyear/ "Happy New Year!"). (Also worth a check! (: Canvas (particles) animations)

Uses svg `clipPath` in combination with a stroke & `stroke-dashoffset`.